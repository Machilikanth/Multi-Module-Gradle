package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.TeacherPojo;
import com.example.service.TeacherService;

@RestController
@RequestMapping("/students")
public class TeacherController {
	
	  @Autowired
	    private TeacherService teacherService;
	   @PostMapping
	    public TeacherPojo createStudent(@RequestBody TeacherPojo student) {
	        return teacherService.save(student);
	    }
}
	