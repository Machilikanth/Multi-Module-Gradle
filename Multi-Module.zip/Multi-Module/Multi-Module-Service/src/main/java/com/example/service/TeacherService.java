package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.TeacherPojo;
import com.example.model.TeacherRepository;

@Service
public class TeacherService {

	@Autowired
	private TeacherRepository studentRepository;
	
	public TeacherPojo save(TeacherPojo student) {
		return studentRepository.save(student);
	}
}
